# Telegram Bot

## Setup
1. Install dependencies:
   pip install -r telegram-bot/requirements.txt

2. Set environment variables:
   TELEGRAM_BOT_TOKEN=your_bot_token_here
   ADMIN_ID=your_telegram_user_id

3. Run:
   cd telegram-bot && python bot.py
